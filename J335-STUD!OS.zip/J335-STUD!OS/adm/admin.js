// Autenticação e Controle de Acesso
let currentUser = null;


// Função de autenticação
async function initAuth() {
  firebase.auth().onAuthStateChanged(async user => {
    console.log(user?.uid)

    if (user && await isAdmin(user.uid)) {
      currentUser = user
      RenderAdminPanel();

      document.body.classList.add('logged-in');
    } else {
      //RenderLoginForm();
      NotADM()
    }
  });
}

function NotADM() {
  const message = encodeURIComponent('Acesso restrito: Você precisa ser administrador!');
  window.location.href = `/?message=${message}&type=error`;
  Loader.hide()
}

function RenderAdminPanel() {
  console.log(currentUser?.uid)
  // Redireciona não autorizados
  if (window.location.pathname.includes('/admin') && !currentUser) {
    NotADM();
  }

  const panel = document.getElementById('adminPanel');
  panel.innerHTML = `
                <h2 class="text-center mb-4">Painel de Administração</h2>
                
                <div class="admin-only">
                    <!-- Formulário de Adição -->
                    <form id="modForm" class="mb-5">
                        <!-- Campos do formulário aqui -->
                    </form>

                    <!-- Lista de Mods para Edição -->
                    <h3 class="mb-3">Mods Existentes</h3>
                    <div id="modsList"></div>
                </div>
            `;

  loadEditableMods();
  setupForm();
  Loader.hide()
}

function RenderLoginForm() {
  document.getElementById('adminPanel').innerHTML = `
                <div class="text-center">
                    <h2 class="mb-4">Acesso Restrito</h2>
                    <button onclick="signInWithGoogle()" class="btn btn-danger">
                        <i class="fab fa-google me-2"></i>Entrar com Google
                    </button>
                </div>
            `;
}

/*
async function signInWithGoogle() {
  const provider = new firebase.auth.GoogleAuthProvider();
  try {
    await firebase.auth().signInWithPopup(provider);
  } catch (error) {
    console.error('Erro de login:', error);
  }
}
*/

// Inicializa quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', initAuth);